/*
import React from 'react';
import './CircleLoader.css';

interface CircleLoaderProps {
  isActive: boolean;
}

const CircleLoader: React.FC<CircleLoaderProps> = ({ isActive }) => {
  return (
    <div className={`circle__box ${isActive ? 'animate' : ''}`}>
      <div className="circle__wrapper circle__wrapper--right">
        <div className="circle__whole circle__right"></div>
      </div>
      <div className="circle__wrapper circle__wrapper--left">
        <div className="circle__whole circle__left"></div>
      </div>
    </div>
  );
};

export default CircleLoader;
*/
